from ultralytics import YOLO
import os
from pathlib import Path

# Step 1: Load the YOLOv11 model
#model = YOLO("runs/detect/yolo12x-4heads-900epoches-visdrone-20250310/weights/best.pt")  # Replace with your trained model path if needed
# CFG = "/root/autodl-tmp/ultralytics/runs/detect/yolo12l-4heads-600epoches-visdrone-sinIoU/train/weights/best.pt"
model = YOLO("/root/autodl-tmp/ultralytics/runs/detect/yolo12l-4heads-600epoches-visdrone-cIoU/train/weights/best.pt")  # Replace with your trained model path if needed
# model = YOLO("/home/david/code/ultralytics/runs/detect/train/weights/best.pt")  # Replace with your trained model path if needed

# Step 2: Define paths to the validation directory
# validation_dir = Path("/home/david/dataset/drone/VisDroneOrigin/VisDrone2019-DET-val")  # Update this path
validation_dir = Path("/autodl-fs/data/mydata/VisDrone/VisDrone2019-DET-val")
images_dir = validation_dir / "images"
labels_dir = validation_dir / "labels"

# Step 3: Validate the dataset and calculate mAP50
results = model.val(
    # data="/home/ubuntu/david/info/visdrone.yaml",  # Path to your dataset YAML file (explained below)
    data="info/visdrone.yaml",
    imgsz=640,         # Input image size
    batch=80,          # Batch size
    conf=0.31,         # Confidence threshold
    iou=0.7,           # IoU threshold for mAP50
    # device=[0,1,2,3,4,5,6,7],
    device="cpu",      # Use "cuda" if GPU is available
    save_json=True,   # Set to True if you want to save results as JSON
    plots=True,         # Generate plots for analysis
    name="val-conf+iou"
)

# Step 4: Access mAP50 from the results
metrics = results.results_dict
map50 = metrics['metrics/mAP50(B)']  # mAP50 for bounding box detection
print(metrics)
print("-------------------------")
print(f"mAP50: {map50:.4f}")
