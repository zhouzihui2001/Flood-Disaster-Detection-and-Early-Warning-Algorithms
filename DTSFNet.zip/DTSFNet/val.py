#!/usr/bin/python3

# import sys
# sys.path.insert(0, '/home/david/code/ultralytics')

# import warnings
# warnings.filterwarnings('ignore')
from ultralytics import YOLO


if __name__ == '__main__':
    # CFG = "/root/autodl-tmp/ultralytics/runs/detect/visdrone-epoches600-4090/weights/best.pt"
    # CFG = "/root/autodl-tmp/ultralytics/runs/detect/yolo12l-4heads-200epoches-visdrone-sinIoU/train2/weights/best.pt"
    # CFG = "/root/autodl-tmp/ultralytics/runs/detect/yolo12l-4heads-600epoches-visdrone-cIoU/train/weights/best.pt"
    CFG = "/root/autodl-tmp/ultralytics/runs/detect/yolo12l-4heads-600epoches-visdrone-sinIoU/train/weights/best.pt"

    model = YOLO(CFG)

    model.val(
        # data='info/uavdt.yaml',
        data='info/visdrone.yaml',
        seed=100,
        cache=False,
        imgsz=640,
        # epochs=600,
        batch=4,        # visdrone: x:4;  l:6;  s:8;    uavdt:
        close_mosaic=10,
        device=[0],
        patience=0,
        project='2025/visdrone640',
        # optimizer='AdamW', # SGD, Adam, AdamW, NAdam, RAdam, RMSProp etc., or auto
        name='runs/detect/yolo12x-4heads-siniou_600epoches-visdrone',
        # name='exp',
    )

# model = YOLO('/root/autodl-tmp/yolov8-main/train/UAVDT/weights/best.pt')
#     model.val(data='ultralytics/cfg/datasets/UAVDT.yaml',
#               split='val',
#               imgsz=1536,
#               batch=4,
#               # rect=False,
#               # save_json=True, # if you need to cal coco metrice
#               project='runs/val',
# #               name='2025/visdrone1536/yolov8-ASF-DySample-EMSC-nwd0.916',
#               name='2025/UAVDT/yolov8NWD0.8',
#               verbose=True,