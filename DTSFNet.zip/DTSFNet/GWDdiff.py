import matplotlib.pyplot as plt
import numpy as np

# 设置数据
methods = ['AF-LWNet (CIoU)', 'AF-LWNet (EIoU)', 'AF-LWNet (GWD)']
p = [61.7, 62.8, 61.6]
r = [49.1, 49.4, 50.1]
map_0_5 = [52.9, 53.2, 53.8]
map_0_75 = [32.7, 32.8, 33.3]

# 设置图表样式和尺寸
plt.style.use('seaborn-v0_8-paper')
plt.figure(figsize=(10, 6))
plt.rcParams.update({'font.family': 'sans-serif', 'font.size': 10})

# 绘制折线图
plt.plot(methods, p, 'p-', label='P', color='#1f77b4', markersize=8)    # 蓝色
plt.plot(methods, r, 'p-', label='R', color='#ff7f0e', markersize=8)    # 橙色
plt.plot(methods, map_0_5, 'p-', label='mAP₀.₅', color='#2ca02c', markersize=8)  # 绿色
plt.plot(methods, map_0_75, 'p-', label='mAP₀.₇₅', color='#d62728', markersize=8)     # 红色

# 添加数据标签
for i, (p_val, r_val, map05_val, map075_val) in enumerate(zip(p, r, map_0_5, map_0_75)):
    plt.text(i, p_val + 0.5, f'{p_val:.1f}', ha='center', va='bottom', fontsize=8)
    plt.text(i, r_val + 0.5, f'{r_val:.1f}', ha='center', va='bottom', fontsize=8)
    plt.text(i, map05_val + 0.5, f'{map05_val:.1f}', ha='center', va='bottom', fontsize=8)
    plt.text(i, map075_val + 0.5, f'{map075_val:.1f}', ha='center', va='bottom', fontsize=8)

# 图表美化
plt.xticks(rotation=0, ha='center')
plt.xlabel('度量方法')
plt.ylabel('Performance (%)')
plt.title('不同度量方法的性能评估')
plt.legend(loc='upper left')
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.ylim(0, 100)  # 设置纵坐标的范围为0到100
plt.tight_layout()

# 显示图表
plt.show()
plt.savefig('GWDdiff.png', dpi=300, bbox_inches='tight')
print("图表已保存为 'GWDdiff.png'")