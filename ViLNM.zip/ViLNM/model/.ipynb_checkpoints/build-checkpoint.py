from model import objectives

from .CrossEmbeddingLayer_tse import TexualEmbeddingLayer, VisualEmbeddingLayer
from .clip_model import build_CLIP_from_openai_pretrained, convert_weights
import torch
import torch.nn as nn 
import torch.nn.functional as F
import numpy as np

def l1norm(X, dim, eps=1e-8):
    """L1-normalize columns of X"""
    norm = torch.abs(X).sum(dim=dim, keepdim=True) + eps
    X = torch.div(X, norm)
    return X


def l2norm(X, dim=-1, eps=1e-8):
    """L2-normalize columns of X"""
    norm = torch.pow(X, 2).sum(dim=dim, keepdim=True).sqrt() + eps
    X = torch.div(X, norm)
    return X

class TBPSModel(nn.Module):
    def __init__(self, args, num_classes=11003):
        super().__init__()
        self.args = args
        self.num_classes = num_classes
        self._set_task()
        self.base_model, base_cfg = build_CLIP_from_openai_pretrained(args.pretrain_choice, args.img_size, args.stride_size)
        
        self.embed_dim = base_cfg['embed_dim']

        self.logit_scale = torch.ones([]) * (1 / args.temperature) 
         
        self.visul_emb_layer = VisualEmbeddingLayer()
        self.texual_emb_layer = TexualEmbeddingLayer()
        
        self.global_classifier = nn.Linear(512, self.num_classes)
        nn.init.normal_(self.global_classifier.weight.data, std=0.001)
        nn.init.constant_(self.global_classifier.bias.data, val=0.0)
        
        self.local_classifier = nn.Linear(1024, self.num_classes)
        nn.init.normal_(self.local_classifier.weight.data, std=0.001)
        nn.init.constant_(self.local_classifier.bias.data, val=0.0)  
        
        if 'InfoNCE' in self.current_task:
            loss_type = 'InfoNCE'
        elif 'SDM' in self.current_task:
            loss_type = 'SDM'
            
        self.loss_type = self.current_task
 
    def _set_task(self):
        loss_names = self.args.loss_names
        self.current_task = [l.strip() for l in loss_names.split('+')]
        print(f'Training Model with {self.current_task} tasks')
    
    def encode_image_global(self, image):
        ix, atten_i = self.base_model.encode_image(image)
        i_feats_global = ix[:, 0, :]
        return i_feats_global.float()
        
    def encode_text_global(self, text):
        x, atten = self.base_model.encode_text(text.long())
        t_feats_global = x[torch.arange(x.shape[0]), text.argmax(dim=-1)]
        return t_feats_global.float()

    def encode_image_local(self, image):
        ix, atten_i = self.base_model.encode_image(image)
        i_local = self.visul_emb_layer(ix, atten_i)
        return i_local.float()

    def encode_text_local(self, text):
        x, atten = self.base_model.encode_text(text.long())
        t_local = self.texual_emb_layer(x, text, atten)
        return t_local.float()

    def compute_id(self, image_logits, text_logits, labels):
        # criterion = LabelSmoothingLoss(self.num_classes)
        criterion = nn.CrossEntropyLoss(reduction="mean")
        loss = criterion(image_logits, labels) + criterion(text_logits, labels)
        return loss / 2
    
    def forward(self, batch):
        ret = dict()
        ret.update({'temperature': 1 / self.logit_scale})
        images = batch['images']
        caption_ids = batch['mlm_ids']
        origin_ids = batch['caption_ids']
        
        image_feats, atten_i, text_feats, atten_t= self.base_model(images, caption_ids)
        
        i_feats_global = image_feats[:, 0, :].float()
        t_feats_global = text_feats[torch.arange(text_feats.shape[0]), caption_ids.argmax(dim=-1)].float()
             
        i_local = self.visul_emb_layer(image_feats, atten_i)
        t_local = self.texual_emb_layer(text_feats, caption_ids, atten_t)
        
        image_g = self.global_classifier(i_feats_global.half()) 
        text_g = self.global_classifier(t_feats_global.half())
        loss_class_g = self.compute_id(image_g,text_g,batch['pids'])
        image_l = self.local_classifier(i_local.half())
        text_l = self.local_classifier(t_local.half())
        loss_class_l = self.compute_id(image_l,text_l,batch['pids']) 
        
        loss_global_match, loss_local_match = objectives.compute_rbs(i_feats_global, t_feats_global, i_local, t_local, batch['pids'],loss_type=self.loss_type,logit_scale=self.logit_scale)  
        
        global_loss = loss_global_match+loss_class_g
        local_loss = loss_local_match+loss_class_l
        
        ret.update({'global_loss': global_loss})
        ret.update({'local_loss': local_loss})
        return ret, image_feats, text_feats

            
def build_model(args, num_classes=11003):
    model = TBPSModel(args, num_classes)
    # covert model to fp16
    convert_weights(model)
    return model
