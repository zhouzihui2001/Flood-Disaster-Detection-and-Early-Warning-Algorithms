import logging
import os
import time
import torch
from utils.meter import AverageMeter
from utils.metrics import Evaluator
from utils.comm import get_rank, synchronize
from torch.utils.tensorboard import SummaryWriter
from prettytable import PrettyTable
import numpy as np
from matplotlib import pyplot as plt
from pylab import xticks,yticks,np
from datasets.build import build_filter_loader
import torch.nn.functional as F

def do_train(start_epoch, args, model, train_loader, evaluator, optimizer,
             scheduler, checkpointer, trainset):

    log_period = args.log_period
    eval_period = args.eval_period
    device = "cuda"
    num_epoch = args.num_epoch
    arguments = {}
    arguments["num_epoch"] = num_epoch
    arguments["iteration"] = 0
    logger = logging.getLogger("TBPSModel.train")
    logger.info('start training')

    meters = {
        "loss": AverageMeter(),
        "local_loss": AverageMeter(),
        "global_loss": AverageMeter(),
    }
    tb_writer = SummaryWriter(log_dir=args.output_dir)
    best_top1 = 0.0
    sims = []
    for epoch in range(start_epoch, num_epoch + 1):
        with torch.no_grad():
            if epoch % 1 == 0 : 
                logger.info('Reconstruct the train loader')
                train_loader = build_filter_loader(args, trainset)
                
        start_time = time.time()
        for meter in meters.values():
            meter.reset()

        model.train()
        model.epoch = epoch
          
        for n_iter, batch in enumerate(train_loader):
            #print(batch)
            batch = {k: v.to(device) for k, v in batch.items()}

            ret, fu_i_feats, fu_t_feats = model(batch)
            total_loss = sum([v for k, v in ret.items() if "loss" in k])
            #print(total_loss)
            with torch.no_grad():
                similarity_matrix = torch.einsum('nld,nkd->nlk', [F.normalize(fu_t_feats,dim=-1), F.normalize(fu_i_feats[:,1:,:],dim=-1)])
                similarity_matrix = similarity_matrix.max(-1)[0] #qu max value
                for idx, sim in zip(batch['image_ids'].data, similarity_matrix):
                    trainset[idx][-1] = sim.data.cpu().numpy()
                    
            batch_size = batch['images'].shape[0]
            meters['loss'].update(total_loss.item(), batch_size)
            meters['global_loss'].update(ret.get('global_loss', 0), batch_size)
            meters['local_loss'].update(ret.get('local_loss', 0), batch_size)
                        
            optimizer.zero_grad()
            total_loss.backward()    
            optimizer.step()
            synchronize()

            if (n_iter + 1) % log_period == 0:
                info_str = f"Epoch[{epoch}] Iteration[{n_iter + 1}/{len(train_loader)}]"
                # log loss and acc info
                for k, v in meters.items():
                    if v.avg > 0:
                        info_str += f", {k}: {v.avg:.4f}"
                info_str += f", Base Lr: {scheduler.get_lr()[0]:.2e}"
                logger.info(info_str)
        
 
        tb_writer.add_scalar('lr', scheduler.get_lr()[0], epoch)
        tb_writer.add_scalar('temperature', ret['temperature'], epoch)
        for k, v in meters.items():
            if v.avg > 0:
                tb_writer.add_scalar(k, v.avg, epoch)

        scheduler.step()
        if get_rank() == 0:
            end_time = time.time()
            time_per_batch = (end_time - start_time) / (n_iter + 1)
            logger.info(
                "Epoch {} done. Time per batch: {:.3f}[s] Speed: {:.1f}[samples/s]"
                .format(epoch, time_per_batch,
                        train_loader.batch_size / time_per_batch))
        if epoch % eval_period == 0:
            if get_rank() == 0:
                logger.info("Validation Results - Epoch: {}".format(epoch))
                if args.distributed:
                    top1 = evaluator.eval(model.module.eval())
                else:
                    top1 = evaluator.eval(model.eval())

                torch.cuda.empty_cache()
                if best_top1 < top1:
                    best_top1 = top1
                    arguments["epoch"] = epoch
                    checkpointer.save("best", **arguments)
 
    if get_rank() == 0:
        logger.info(f"best R1: {best_top1} at epoch {arguments['epoch']}")

    arguments["epoch"] = epoch
    checkpointer.save("last", **arguments)
                    
def do_inference(model, test_img_loader, test_txt_loader):

    logger = logging.getLogger("TBPSModel.test")
    logger.info("Enter inferencing")

    evaluator = Evaluator(test_img_loader, test_txt_loader)
    top1 = evaluator.eval(model.eval())
