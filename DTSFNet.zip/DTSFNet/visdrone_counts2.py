

# # 数据准备
# categories = ['行人', '人群', '自行车', '汽车', '厢式车', 
#               '卡车', '三轮车', '篷式三轮车', '公交车', '摩托车']
# large = [306, 99, 127, 11936, 2862, 2167, 210, 186, 1000, 267]
# medium = [13793, 3450, 3250, 63084, 11523, 6724, 2423, 1695, 3269, 7409]
# small = [65238, 23508, 7102, 69844, 10751, 3984, 2179, 1365, 1657, 21971]

import matplotlib.pyplot as plt
import numpy as np

import matplotlib.font_manager as fm


# 列出所有可用字体
for font in fm.fontManager.ttflist:
    if 'hei' in font.name.lower() or 'yahei' in font.name.lower():
        print(font.name, font.fname)

plt.rcParams['font.sans-serif'] = ['DejaVu Sans']  # 部分Linux系统支持中文
plt.rcParams['axes.unicode_minus'] = False
# 数据准备（保持英文类别名）
categories = ['pedestrain', 'people', 'bicycle', 'car', 'van', 
              'truck', 'tricycle', 'awning-tricycle', 'bus', 'motor']
large = [306, 99, 127, 11936, 2862, 2167, 210, 186, 1000, 267]
medium = [13793, 3450, 3250, 63084, 11523, 6724, 2423, 1695, 3269, 7409]
small = [65238, 23508, 7102, 69844, 10751, 3984, 2179, 1365, 1657, 21971]

# 设置支持中文的字体（根据系统选择可用字体）
# try:
#     rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 雅黑
#     rcParams['axes.unicode_minus'] = False
# except:
#     try:
#         rcParams['font.sans-serif'] = ['SimHei']  # 黑体
#         rcParams['axes.unicode_minus'] = False
#     except:
#         rcParams['font.sans-serif'] = ['Arial Unicode MS']  # Mac

# 设置图形大小
plt.figure(figsize=(14, 10))

# 计算堆叠位置（小 → 中 → 大）
small_stack = np.array(small)
medium_stack = small_stack + np.array(medium)
large_stack = medium_stack + np.array(large)
total = large_stack

# 绘制堆叠条形图（中文图例）
plt.barh(categories, small, color='red', label='小目标')
plt.barh(categories, medium, left=small_stack, color='gold', label='中等目标')
plt.barh(categories, large, left=medium_stack, color='blue', label='大目标')

# 添加数值标注（优化显示位置）
for i, (s, m, l) in enumerate(zip(small, medium, large)):
    # 小目标标注
    if s > 0:
        plt.text(total[i] + total.max()*0.08, i - 0.2, f'小: {s}', 
                va='center', ha='left', color='red', fontsize=9)
        arrow = FancyArrowPatch(
            (small_stack[i], i - 0.2), (total[i] + total.max()*0.03, i - 0.2),
            arrowstyle='->', color='red', mutation_scale=12)
        plt.gca().add_patch(arrow)
    
    # 中等目标标注
    if m > 0:
        plt.text(total[i] + total.max()*0.08, i, f'中: {m}', 
                va='center', ha='left', color='black', fontsize=9)
        arrow = FancyArrowPatch(
            (medium_stack[i], i), (total[i] + total.max()*0.03, i),
            arrowstyle='->', color='gold', mutation_scale=12)
        plt.gca().add_patch(arrow)
    
    # 大目标标注
    if l > 0:
        plt.text(total[i] + total.max()*0.08, i + 0.2, f'大: {l}', 
                va='center', ha='left', color='blue', fontsize=9)
        arrow = FancyArrowPatch(
            (large_stack[i], i + 0.2), (total[i] + total.max()*0.03, i + 0.2),
            arrowstyle='->', color='blue', mutation_scale=12)
        plt.gca().add_patch(arrow)

# 调整坐标轴范围
plt.xlim(0, total.max() * 1.2)

# 添加图例和标题（中文）
plt.xlabel('数量', fontsize=12)
plt.ylabel('Categories', fontsize=12)  # 保持英文
plt.title('目标尺寸分布统计（小→中→大）', pad=20, fontsize=14)
plt.legend(loc='lower right', fontsize=10)

# 保存和显示
plt.tight_layout()
plt.savefig('target_distribution_chinese.png', dpi=300, bbox_inches='tight')
plt.show()
print("图表已保存为 'target_distribution.png'")