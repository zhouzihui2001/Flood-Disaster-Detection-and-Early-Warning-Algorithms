#!/usr/bin/python3

# import sys
# sys.path.insert(0, '/home/david/code/ultralytics')

# import warnings
# warnings.filterwarnings('ignore')
from ultralytics import YOLO


if __name__ == '__main__':
    CFG = "info/model.yaml"

    model = YOLO(CFG)

    model.train(
        data='info/visdrone.yaml',
        # data='info/visdrone.yaml',
        seed=100,
        cache=False,
        imgsz=640,
        epochs=600,
        batch=4,        # visdrone: x:4;  l:6;  s:8;    uavdt:
        close_mosaic=10,
        device=[0],
        patience=0,
        # optimizer='AdamW', # SGD, Adam, AdamW, NAdam, RAdam, RMSProp etc., or auto
        project='runs/detect/yolo12l-4heads-600epoches-visdrone-sinIoU',
        # name='exp',
    )