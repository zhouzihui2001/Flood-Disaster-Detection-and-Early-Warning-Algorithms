import math
import torch
import torch.nn as nn
import torch.nn.functional as F
 
def compute_sdm_per(scores,  pid, logit_scale, epsilon=1e-8):
    """
    Similarity Distribution Matching
    """
    batch_size = scores.shape[0]
    pid = pid.reshape((batch_size, 1)) # make sure pid size is [batch_size, 1]
    pid_dist = pid - pid.t()
    labels = (pid_dist == 0).float()

    t2i_cosine_theta = scores
    i2t_cosine_theta = t2i_cosine_theta.t()

    text_proj_image = logit_scale * t2i_cosine_theta
    image_proj_text = logit_scale * i2t_cosine_theta

    # normalize the true matching distribution
    labels_distribute = labels / labels.sum(dim=1)  
    i2t_pred = F.softmax(image_proj_text, dim=1)
    i2t_loss = i2t_pred * (F.log_softmax(image_proj_text, dim=1) - torch.log(labels_distribute.t() + epsilon))
    i2t_loss_label = (labels_distribute.t()) * (torch.log(labels_distribute.t() + epsilon) - F.log_softmax(image_proj_text, dim=1))
        
    t2i_pred = F.softmax(text_proj_image, dim=1)
    t2i_loss = t2i_pred * (F.log_softmax(text_proj_image, dim=1) - torch.log(labels_distribute + epsilon))
    t2i_loss_label = (labels_distribute) * (torch.log(labels_distribute + epsilon) - F.log_softmax(text_proj_image, dim=1))
    loss = torch.mean(torch.sum(i2t_loss, dim=1))  + torch.mean(torch.sum(t2i_loss, dim=1))+torch.mean(torch.sum(i2t_loss_label, dim=1)) + torch.mean(torch.sum(t2i_loss_label, dim=1))
    return loss
    
import torch.nn as nn 
import torch.nn.functional as F
def compute_InfoNCE_per(scores, unique_scores, intra_text_scores, intra_image_scores, pid, unique_pid, logit_scale):
    unique_pid_dist = unique_pid - unique_pid.t()
    unique_labels = (unique_pid_dist == 0).float()
    unique_mask = 1 - unique_labels
    
    batch_size = scores.shape[0]
    pid = pid.reshape((batch_size, 1)) # make sure pid size is [batch_size, 1]
    pid_dist = pid - pid.t()
    labels = (pid_dist == 0).float()
    mask = 1 - labels

    # cosine similarity as logits
    logits_per_t2i = logit_scale * scores #t2i
    logits_per_i2t = logits_per_t2i.t() #i2t
    
    unique_logits_per_t2i = logit_scale * unique_scores #t2i
    unique_logits_per_i2t = unique_logits_per_t2i.t() #i2t
    intra_text_scores = logit_scale * intra_text_scores
    intra_image_scores = logit_scale * intra_image_scores
            
    p1 = (logits_per_t2i.exp() / (logits_per_t2i.exp()).sum(dim=1, keepdim=True))
    p2 = (logits_per_i2t.exp() / (logits_per_i2t.exp()).sum(dim=1, keepdim=True))
        
    intra_p1 =(unique_logits_per_t2i.exp() / (intra_text_scores.exp()*unique_mask).sum(dim=1, keepdim=True))
    intra_p2 = (unique_logits_per_i2t.exp() / (intra_image_scores.exp()*(unique_mask.t())).sum(dim=1, keepdim=True))
         
    loss = (- p1.diag().log() - p2.diag().log())/2
    intra_loss = (- intra_p1.diag().log() - intra_p2.diag().log())/2        
    return loss, intra_loss

def compute_rbs(i_feats, t_feats, i_tse_f, t_tse_f , pid, loss_type='TAL', logit_scale=50):
    
    loss_global, _ = compute_per_loss(i_feats, t_feats, pid, loss_type, logit_scale)
    loss_local, _ = compute_per_loss(i_tse_f, t_tse_f, pid, loss_type, logit_scale)    
    return loss_global, loss_local
        
def compute_per_loss(image_features, text_features, pid, loss_type='InfoNCE', logit_scale=50):
    
    # # normalized features
    image_norm = image_features / image_features.norm(dim=-1, keepdim=True)
    text_norm = text_features / text_features.norm(dim=-1, keepdim=True)
    scores = text_norm @ image_norm.t()
    
    pid_list=[]
    unique_intra_text=[]
    unique_intra_image=[]
    for pid_item, text,image in zip(pid.reshape((image_features.shape[0], 1)),text_norm, image_norm):
        pid_list.append(pid_item)
        unique_intra_text.append(text)
        unique_intra_image.append(image)
    unique_pid = torch.stack(pid_list)
    unique_image_norm = torch.stack(unique_intra_text)
    unique_text_norm = torch.stack(unique_intra_image)
    unique_scores = unique_text_norm @ unique_image_norm.t()
    intra_text_scores = unique_text_norm @ unique_text_norm.t()
    intra_image_scores = unique_image_norm @ unique_image_norm.t()
    
    if 'InfoNCE' in loss_type:
        infonce_loss, intra_loss = compute_InfoNCE_per(scores, unique_scores, intra_text_scores, intra_image_scores, pid, unique_pid, logit_scale)
    if 'SDM' in loss_type:
        sdm_loss = compute_sdm_per(scores,  pid, logit_scale)
    
    per_loss = torch.mean(infonce_loss)+sdm_loss+torch.mean(intra_loss)/10
    return per_loss, scores.diag()
  
