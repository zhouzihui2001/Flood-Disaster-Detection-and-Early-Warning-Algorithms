#!/bin/bash
root_dir=../tbps_data
loss=InfoNCE+SDM
DATASET_NAME=CUHK-PEDES
# CUHK-PEDES ICFG-PEDES RSTPReid
CUDA_VISIBLE_DEVICES=0 \
    python train.py \
    --name Model \
    --img_aug \
    --txt_aug \
    --batch_size 512 \
    --root_dir $root_dir \
    --output_dir run_logs \
    --dataset_name $DATASET_NAME \
    --loss_names ${loss}  \
    --num_epoch 60 
